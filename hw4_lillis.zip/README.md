# COMPSCI-589-Homework-4

My code can be run via the command ``python3 main.py``. It takes no additional command line arguments. 

Different parts of the project can be run by inserting/ uncommenting various function calls within ``src/main.py``'s ``main()`` function.

The code's dependencies are 

- the ``csv`` module
- the ``random`` module
- the ``os`` module
- the ``numpy`` module
- the ``deepcopy()`` function from the ``copy`` module